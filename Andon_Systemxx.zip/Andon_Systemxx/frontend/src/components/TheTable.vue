<template>
  <div>
    <h3>ライン稼働状況</h3>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>計画台数(累計)</th>
          <th>生産台数(累計)</th>
          <th>稼働率</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>{{rates[0].plannedNumber}}台</td>
          <td>20台</td>
          <td>-%</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  components: {},
  data: function () {
    return {
      rates:[""],
      a:0,
    };
  },
  methods: {
     getRates:function(){
       const path = "http://127.0.0.1:5000/increasedPlanned"
       axios.get(path).then((response) =>{
         const dat = response.data;
         let getData = []
         getData.splice(0, 0, {
           plannedNumber:dat[0].plannedNumber,
         });
        this.rates = getData;
        console.log(this.rates[0].plannedNumber);
       }).catch((error)=>{
         console.log(error)
       })
     },

    incrementRate:function(){
       setInterval(() => {
        this.rates[0].plannedNumber = this.rates[0].plannedNumber + 1;
        console.log(this.rates[0].plannedNumber);
      }, 2000);
    }
  },
  mounted(){
    this.getRates()
    this.incrementRate()
  },
  computed: {},
};
</script>
<style scoped>
table,
td,
th {
  border: 1px solid black;
}

table {
  border-collapse: collapse;
  width: 50%;
  text-align: center;
  position: relative;
  left: 525px;
  top: -841px;
}

th {
  height: 10px;
  background: #292c2e;
}

h3 {
  position: relative;
  left: 525px;
  top: -843px;
}
</style>
