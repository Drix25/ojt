<template>
  <div class="container">
    <div class="row">
      <div class="col-6 col-md-4">
        <utilization-table></utilization-table>
        <utilization-operationchart></utilization-operationchart>
      </div>
    </div>
  </div>
</template>

<script>
import UtilizationTable from "./UtilizationTable";
import UtilizationOperationchart from "./UtilizationOperationchart.vue";

export default {
  components: { UtilizationTable, UtilizationOperationchart },
};
</script>
