<template>
  <div class="row row-cols-2">
    <div class="col-8 col-md-6">
      <figure class="text-center">稼働状況</figure>
    </div>
    <div class="col-4 col-md-6">
      <figure class="text-center process">準備中</figure>
    </div>
  </div>
</template>

<script>
//import Textbox from "./Textbox.vue";
export default {
  // components: { Textbox },
  data: function () {
    return {
      opPrep: true,
      opAct: false,
      opSt: false,
    };
  },
  methods: {
    incrementInterval: function () {
      //para sa pagchange ng process
      setInterval(() => {
        //para sa pagchange ng kulay
        setTimeout(() => {
          //Para makuha yung  element class name

          //condition para mabago yung kulay kada process
          let theDivElement = document.getElementsByClassName("col-4 col-md-6"); //90
          let textColor = document.getElementsByClassName("text-center process")

          if (this.opPrep) {
            theDivElement[0].style.backgroundColor = "yellow";
            textColor[0].style.color = "black"
            textColor[0].textContent = "準備中"
            //theDivElement[0].style.fontcolor = "#000";
            //targetColor = this.elementColor[0];
            this.opPrep = false;
            this.opAct = true;
            //console.log(theDivElement);
          } else if (this.opAct) {
            //this.elementColor = "green";
            theDivElement[0].style.backgroundColor = "green";
            textColor[0].style.color = "white"
            this.opAct = false;
            this.opSt = true;
            textColor[0].textContent = "稼働中"
            // console.log(this.process);
          } else {
            //this.elementColor = "red";
            theDivElement[0].style.backgroundColor = "red";
            textColor[0].style.color = "white"
            this.opPrep = true;
            this.opSt = false;
            textColor[0].textContent = "異常停止"
          }
        }, 500);
      }, 2000);
    },
  },
  mounted() {
    this.incrementInterval();
  },
};
</script>

<style scoped>
figure {
  margin-bottom: 0;
}
.col-md-6 {
  border-width: 1px;
  border-style: solid;
}

.row-cols-2 {
  margin: 3% 0;
}
</style>
