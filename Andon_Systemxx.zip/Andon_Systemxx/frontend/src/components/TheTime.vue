<template>
  <span class="">{{ dateAndTime }}</span>
</template>

<script>
export default {
  components: {},
  data: function () {
    return { dateAndTime: null };
  },
  created() {
    setInterval(this.getNow, 1000);
  },
  methods: {
    getNow() {
      const today = new Date();
      const date =
        today.getFullYear() +
        "/" +
        (today.getMonth() + 1).toString().padStart(2, "0") +
        "/" +
        today.getDate().toString().padStart(2, "0");
      const time =
        today.getHours().toString().padStart(2, "0") +
        ":" +
        today.getMinutes().toString().padStart(2, "0") +
        ":" +
        today.getSeconds().toString().padStart(2, "0");
      const dateTime = date + " " + time;
      this.dateAndTime = dateTime;
    },
  },
  computed: {},
};
</script>

<style scoped></style>
