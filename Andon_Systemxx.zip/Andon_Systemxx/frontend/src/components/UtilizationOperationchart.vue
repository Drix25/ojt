<template>
  <div class="container">
    <div class="row">
      <div class="col align-self-center">
        <div class="chart-line">
          <div>
            <div v-for="p in processes" :class = p.className :style="{left:p.coordsX+`px`,top:p.coordsY + `px`, height: p.coordsH + `px`,width: p.coordsW + `px`}" :key="p.pro">{{p.processNumber}}</div>
          </div>  
        </div> 
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  

  data: function () {
    return {
      // dX: 0,
      // dY: 0,
      // x: null,
      processes:[],
      process: "Preparation",
      theDiv: [
        "one",
        "two",
        "three",
        "four",
        "five",
        "six",
        "seven",
        "eight",
        "nine",
        "ten",
        "eleven",
        "twelve",
        "thirteen",
        "fourteen",
      ],
      a: 0,
    };
  },
  methods: {
    getdata:function(){
      const backendPath = "http://127.0.0.1:5000/"
      axios.get(backendPath).then((response) =>{
        const dat= response.data;
        console.log(dat);
        let respProcess = []
        for(let key in dat){
          respProcess.splice(0, 0,{
            processInfo:dat[key].processInfo,
            processNumber:dat[key].processNumber,
            coordsH:dat[key].coordsH,
            coordsW:dat[key].coordsW,
            coordsX:dat[key].coordsX,
            coordsY:dat[key].coordsY,
            className:dat[key].className,
          });
        }
        this.processes = respProcess;
        
      })
      .catch((response) => {
        console.log("Error" + response);
      }
      );
    },

    incrementInterval: function () {
      //para sa pagchange ng process
      setInterval(() => {
        //para sa pagchange ng kulay
        setTimeout(() => {
          //Para makuha yung  element class name

          //condition para mabago yung kulay kada process
          if (this.a > 13) {
            this.a = 0;
          }
          //console.log(this.a);
          let theDivElement = document.getElementsByClassName(
            this.theDiv[this.a] + "-pro"
          ); //90

          if (this.process === "Preparation") {
            theDivElement[0].style.backgroundColor = "yellow";
            theDivElement[0].style.color = "black"
            this.process = "Running";

          } else if (this.process === "Running") {
            this.process = "stop";
            theDivElement[0].style.color = "white"
            theDivElement[0].style.backgroundColor = "green";

          } else {
            this.divNumber = "two";
            this.process = "Preparation";
            theDivElement[0].style.color = "white"
            theDivElement[0].style.backgroundColor = "red";
            this.a = this.a + 1;
          }
          
        }, 500);
      }, 2000);
    },
    movementObj: function () {
      // pang paste ng mga txt box
      
      this.getdata();
      this.incrementInterval();
        
    },
  },
  mounted() {
    this.movementObj();
  },
};
</script>

<style scoped>
.chart-line {
  background-image: url("../img/linechart.jpg");
  background-repeat: no-repeat;
  height: 800px;
  width: auto;
  position: relative;
}

.bg {
  background-color: red;
  position: absolute;
  height: 45px;
  width: 45px;
  color: white;
  text-align: center;
  display: flex;
  justify-content: center;
  align-items: center;
}

</style>
