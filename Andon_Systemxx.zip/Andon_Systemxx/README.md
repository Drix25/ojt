# reeltime-andon-system

Change DATABASE URI path in **init**.py file base on your database and restore the
AndonSystemTemporaryDB.sql in PostgreSQL
