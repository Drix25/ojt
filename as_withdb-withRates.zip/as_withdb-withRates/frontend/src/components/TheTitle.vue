<template>
  <span class=""><strong>GSP3</strong>ミリ波1号ライン</span>
</template>

<script>
export default {
  components: {},
  data: function () {
    return {};
  },
  methods: {},
  computed: {},
};
</script>

<style scoped></style>
