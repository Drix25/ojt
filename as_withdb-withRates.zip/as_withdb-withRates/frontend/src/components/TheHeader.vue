<template>
  <header class="box">
    <the-title class="title"></the-title>
    <the-time class="dateAT"></the-time>
  </header>
</template>

<script>
import TheTitle from "./TheTitle.vue";
import TheTime from "./TheTime.vue";
export default {
  components: { TheTitle, TheTime },
  data: function () {
    return {};
  },
  methods: {},
  computed: {},
};
</script>

<style scoped>
div {
  width: auto;
}
span {
  padding: 0 1em;
}
.box {
  background: #292c2e;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  width: 100%;
  height: 5em;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.title {
  font-size: 30px;
}
.dateAT {
  font-size: 15px;
}
</style>
