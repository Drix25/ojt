<template>
  <div id="app">
    <the-header></the-header>
    <utilization-tab></utilization-tab>
    <the-table></the-table>
  </div>
</template>

<script>
import TheHeader from "./components/TheHeader.vue";
import UtilizationTab from "./components/UtilizationTab.vue";
import TheTable from "./components/TheTable.vue";

export default {
  components: { TheHeader, UtilizationTab, TheTable },
  data: function () {
    return {};
  },
  methods: {},
  computed: {},
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
  color: white;
}
html {
  height: 100%;
}
body {
  background: #424846;
  min-height: 100%;
}
</style>
