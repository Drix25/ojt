from backend import db
from datetime import datetime


class Process(db.Model):
    __tablename__ = 'process'

    id = db.Column(db.Integer,primary_key=True)
    processNumber = db.Column(db.String(64),nullable=False)
    processInfo = db.Column(db.String(64),nullable=False)
    coordsX = db.Column(db.Integer,nullable=False)
    coordsY=db.Column(db.Integer,nullable=False)
    coordsW=db.Column(db.Integer,nullable=False)
    coordsH=db.Column(db.Integer,nullable=False)
    className=db.Column(db.String(255),nullable=False)

    def __init__(self,processNumber,processInfo,coordsX,coordsY,coordsW,coordsH,className):
        self.processInfo = processInfo
        self.processNumber = processNumber
        self.coordsX = coordsX
        self.coordsY = coordsY
        self.coordsH = coordsH
        self.coordsW = coordsW
        self.className = className

    def get_dict(self):
        return{
            'id':self.id,
            'processInfo':self.processInfo,
            'processNumber':self.processNumber,
            'coordsX':self.coordsX,
            'coordsY':self.coordsY,
            'coordsH':self.coordsH,
            'coordsW':self.coordsW,
            'className':self.className
        }

    def save_to_db(self):
        db.session.add(self)
        db.session.commit()

class Rate(db.Model):

    __tablename__ = 'rate'

    id = db.Column(db.Integer,primary_key=True)
    plannedNumber = db.Column(db.Integer,nullable =False)

    def __int__(self, plannedNumber):
        self.plannedNumber = plannedNumber
        

    def get_dict(self):
        return{
            'id':self.id,
            'plannedNumber':self.plannedNumber,
            }

    def save_to_db(self):
        db.session.add(self)
        db.session.commit() 
