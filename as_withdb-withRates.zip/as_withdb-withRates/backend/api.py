from flask import Blueprint, json, jsonify,request
from backend.model import db, Process, Rate
from flask_cors import CORS


api_bp = Blueprint('api_bp',__name__)
CORS(api_bp)

@api_bp.route("/", methods=['GET','POST'])
def getProcessPosition():
    
    if (request.method == 'GET'):
        processes = Process.query.all()
        return jsonify([pro.get_dict() for pro in processes])

    if(request.method == 'POST'):
        processes = Process(processInfo=request.json['processInfo'],processNumber = request.json['processNumber'],coordsX=request.json['coordsX'],coordsY=request.json['coordsY'],
        coordsH=request.json['coordsH'],
        coordsW=request.json['coordsW'],
        className=request.json['className'])

        processes.save_to_db();
        return jsonify(status='ok')
    return{'status':'okay'}

@api_bp.route("/delete/<int:id>", methods=['DELETE'])
def tryDelete(id):
    process = Process.query.get_or_404(id)
    db.session.delete(process)
    db.session.commit()
    return jsonify(status='ok')

@api_bp.route("/increasedPlanned", methods=['GET','PATCH'])
def plannedNumber():

    if (request.method == 'GET'):
        plan = Rate.query.all()
        return jsonify([rate.get_dict() for rate in plan])

    if (request.method == 'PATCH'):
        plan = Rate.query.get_or_404(1)
        plan.plannedNumber = request.json['plannedNumber']
        db.session.commit()
        return jsonify(status='ok')

    #Pang add ng data sa Rate Column
    #if(request.method == 'POST'):
     #   plan = Rate(plannedNumber = request.json['plannedNumber'])

        #plan.save_to_db();
        #return jsonify(status='ok')
    return jsonify(status = 'K')